<h3>Selecting mathematics</h3>

<p>Mathslate does not the allow the selection of individual characters as with a word processor, but instead treats mathematics as blocks of code associated with well defined mathematical expressions. A selected expression appears highlighted in the work space, and the block of code appears with a cursor in front of it below the work space.
<h3>Moving mathematics</h3>

<p>To move an expression simply select an element after the place it should be inserted on work space and then click the expression to move there. Alternatively, you may simply drag the expression to where it should be inserted.

<h3>Editing functions</h3>

<p>There is a row of buttons in the center of the editor that allows the user to delete a selection or the whole content, undo the previous action, and redo previously undone actions.

<p><a href="http://docs.moodle.org/26/en/TinyMCE_Mathslate" target="_blank">more information</a>
